package Examenes.examen20221123;

public class Ejercicio03 {
	/*
	 * Todos los metodos estan el la clase utils .
	 */
	public static void main(String[] args) {
		double numeros [] = new double[10];
		numeros[0] = 1 ;
		numeros[1] = 1 ; 
		utils.mostrarArrayD(numeros);
		utils.rellenaArrayRafanacci(numeros);
		utils.mostrarArrayD(numeros);

	}

}

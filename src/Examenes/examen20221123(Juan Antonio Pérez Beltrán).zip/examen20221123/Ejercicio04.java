package Examenes.examen20221123;

public class Ejercicio04 {
	/*
	 * Todos los metodos estan el la clase utils .
	 */
	public static void main(String[] args) {
		char[] frase = new char[] {'H','o','l','a',' ','M','u','n','d','o'} ;
		utils.mostrarArrayC(frase);
		System.out.println("La frase del array en minusculas es : "+utils.minúsculas(frase));
	}

}
